// Reads two force sensors and a Trill Flex touch sensor, sends data via OSC, and prints to console

#include <Bela.h>
#include <libraries/Trill/Trill.h>
#include <libraries/Gui/Gui.h>
#include <libraries/Pipe/Pipe.h>
#include <libraries/Trill/CentroidDetection.h>
#include <libraries/OscSender/OscSender.h>
#include <cmath>

#define NUM_TOUCH 4  // Maximum number of simultaneous touches tracked

Trill touchSensor;           // Trill Flex sensor object
Gui gui;                     // GUI for visualization
Pipe gPipe;                  // Pipe for GUI commands
CentroidDetection cd;        // Detects touch centroids

// Arrays to hold touch information
float gTouchLocation[NUM_TOUCH] = {0.0};  // Normalized positions (0.0 to 1.0)
float gTouchSize[NUM_TOUCH]     = {0.0};  // Touch sizes (intensity)
int gNumActiveTouches = 0;              // Number of detected touches

// Force sensor configuration
int analogChannel1 = 0;  // AIN0
int analogChannel2 = 1;  // AIN1
float lastVal1 = 0.0, lastVal2 = 0.0;     // Last sent values
float threshold1 = 0.01, threshold2 = 0.01; // Change thresholds
float gain1 = 3.0, gain2 = 3.0;            // Amplify readings
unsigned int frameCounter = 0;
unsigned int printInterval = 220;         // Frames between forced sends

// GUI update period
float gTimePeriod = 0.015;  // Seconds

// OSC sender configuration
OscSender oscSender;
int remotePort = 9999;                  // Port for Max/MSP
const char* remoteIp = "192.168.7.1"; // IP of the Max/MSP host

// GUI command identifiers
typedef enum {
	kPrescaler,
	kBaseline,
	kNoiseThreshold,
	kNumBits,
	kMode,
} ids_t;

// Command struct for GUI
struct Command {
	ids_t id;
	float value;
};

// Map GUI control names to command IDs
std::vector<std::pair<std::wstring, ids_t>> gKeys = {
	{L"prescaler", kPrescaler},
	{L"baseline", kBaseline},
	{L"noiseThreshold", kNoiseThreshold},
	{L"numBits", kNumBits},
	{L"mode", kMode},
};

// GUI callback: send commands to the loop thread
bool guiCallback(JSONObject& json, void*)
{
	Command command;
	for(auto& k : gKeys) {
		if(json.find(k.first) != json.end() && json[k.first]->IsNumber()) {
			command.id    = k.second;
			command.value = json[k.first]->AsNumber();
			gPipe.writeNonRt(command);
		}
	}
	return false;
}

// Auxiliary thread: read raw Trill data and update centroids
void loop(void*)
{
	int numBits;
	int speed = 0;
	while(!Bela_stopRequested()) {
		touchSensor.readI2C();                        // Read from Trill
		cd.process(touchSensor.rawData.data());      // Compute centroids
		for(unsigned int i = 0; i < cd.getNumTouches(); i++) {
			gTouchLocation[i] = cd.touchLocation(i);  // Save position
			gTouchSize[i]     = cd.touchSize(i);      // Save size
		}
		gNumActiveTouches = cd.getNumTouches();       // Save count

		// Process GUI commands
		Command command;
		while(gPipe.readRt(command) == 1) {
			switch(command.id) {
				case kPrescaler:
					rt_printf("Setting prescaler to %.0f\n", command.value);
					touchSensor.setPrescaler(command.value);
					break;
				case kBaseline:
					rt_printf("Resetting baseline\n");
					touchSensor.updateBaseline();
					break;
				case kNoiseThreshold:
					rt_printf("Setting noiseThreshold to %f\n", command.value);
					touchSensor.setNoiseThreshold(command.value);
					break;
				case kNumBits:
					rt_printf("Setting number of bits to %d\n", (int)command.value);
					touchSensor.setScanSettings(speed, (int)command.value);
					break;
				case kMode:
					rt_printf("Setting mode to %.0f\n", command.value);
					touchSensor.setMode((Trill::Mode)command.value);
					break;
			}
		}
		usleep(50000);  // Sleep for 50 ms
	}
}

// Setup function: initialize sensors, GUI, OSC
bool setup(BelaContext *context, void *userData)
{
	// Init Trill Flex
	if(touchSensor.setup(1, Trill::FLEX) != 0) {
		fprintf(stderr, "Unable to initialise Trill Flex\n");
		return false;
	}
	touchSensor.setMode(Trill::DIFF);
	cd.setup(30, NUM_TOUCH, 3200);

	// Init GUI
	gui.setup(context->projectName);
	gui.setControlDataCallback(guiCallback, nullptr);
	gPipe.setup("guiToLoop");

	// Start the auxiliary thread
	Bela_runAuxiliaryTask(loop);

	// Init OSC sender
	oscSender.setup(remotePort, remoteIp);

	rt_printf("Setup complete\n");
	return true;
}

// Render loop: read force sensors, print/send data, update/send touch data
void render(BelaContext *context, void *userData)
{
	static unsigned int count = 0;

	for(unsigned int n = 0; n < context->audioFrames; ++n) {
		// Read force sensors
		float val1 = analogRead(context, n, analogChannel1) * gain1;
		float val2 = analogRead(context, n, analogChannel2) * gain2;

		// Send if above threshold change or interval
		if ((val1 > 0.05f || val2 > 0.05f) &&
		    (fabs(val1 - lastVal1) > threshold1 ||
		     fabs(val2 - lastVal2) > threshold2 ||
		     frameCounter >= printInterval)) {
			rt_printf("Force 1: %.3f\tForce 2: %.3f\n", val1, val2);
			lastVal1 = val1; lastVal2 = val2;
			frameCounter = 0;
			// Send OSC /force message
			oscSender.newMessage("/force").add(val1).add(val2).send();
		} else {
			frameCounter++;
		}

		// Periodic touch update
		if(count >= gTimePeriod * context->audioSampleRate) {
			// Send GUI buffers
			gui.sendBuffer(0, touchSensor.getNumChannels());
			gui.sendBuffer(1, touchSensor.rawData);
			gui.sendBuffer(2, gNumActiveTouches);
			gui.sendBuffer(3, gTouchLocation);
			gui.sendBuffer(4, gTouchSize);

			// Print touches
			rt_printf("Touches: %d\n", gNumActiveTouches);
			for(int i = 0; i < gNumActiveTouches; i++) {
				rt_printf("  Touch %d - Location: %.3f, Size: %.3f\n",
				         i, gTouchLocation[i], gTouchSize[i]);
				// Send OSC /touch message
				oscSender.newMessage("/touch")
				         .add(i)
				         .add(gTouchLocation[i])
				         .add(gTouchSize[i])
				         .send();
			}

			count = 0;
		}
		count++;
	}
}

void cleanup(BelaContext *context, void *userData) {
	// No cleanup needed
}
